import numpy as np

theta1=0.1
theta2=0.1
a=5
b=4

ans_x=a*np.cos(theta1) + b*np.cos(theta1+theta2)
ans_y=a*np.sin(theta1) + b*np.sin(theta1+theta2)


def jacobian(theta):
    j11=(-a*np.sin(theta[0][0])) - (b*np.sin(theta[0][0]+theta[1][0]))
    j21=(a*np.cos(theta[0][0])) +(b*np.cos(theta[0][0]+theta[1][0]))
    j12= -b*np.sin(theta[0][0] + theta[1][0])
    j22= b*np.cos(theta[0][0]+theta[1][0])

    jacobian = np.array([[j11,j12],[j21,j22]])
    ans=np.linalg.inv(jacobian)

    return ans


def residual(x, y, theta):
    f1= a*np.cos(theta[0][0]) + b*np.cos(theta[0][0]+theta[1][0])-x
    f2= a*np.sin(theta[0][0]) + b*np.sin(theta[0][0]+theta[1][0])-y

    residual = np.array([[f1,f2]])
    return residual.transpose()

def NR(theta, j, r):
    for i in range (1,100):
        theta=theta-eta* np.dot(j,r)
        j=jacobian(theta)
        r=residual(x,y,theta)

    return theta

def atan2(coss):
    sin_ps=np.sqrt(1-coss**2)
    sin_ng= np.sqrt(1-coss**2)*(-1)
    first=np.arctan2(sin_ps, coss)
    second=np.arctan2(sin_ng, coss)
    return first, second



x=2
y=3
eta=0.2


theta= np.array([[theta1,theta2]])
theta= theta.transpose()
j=jacobian(theta)
r=residual(x,y,theta)


theta=NR(theta, j,r)
print()
print("Solution of Inverse kinematic(joint angles) using newton raphson :")
print( '(' + str(theta[0][0]) + "," + str(theta[1][0])+')')
print()


print("Solution of Inverse kinematic using ATN2 function to verify: ")
cost2=(x*x+y*y-a*a-b*b)/(2*a*b)
sint2=np.sqrt(1-cost2**2)
cost1=(x*(a+b*cost2)+y+b*sint2)/(x**2 + y**2)

theta11,theta12=atan2(cost1)
theta21,theta22=atan2(cost2)
print('('+str(theta11)+' '+str(theta12)+')'+'and')
print('('+str(theta21)+' '+str(theta22)+')')
print()



print("Solution of Foward kinematic using joint angles calculated through ATANJ2 function: ")
print(a*np.cos(theta11) + b*np.cos(theta11+theta21))
print(a*np.sin(theta11) + b*np.sin(theta11+theta21))


















    
    
